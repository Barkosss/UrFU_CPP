#include "Polynom.h"
Polynom multi(Polynom*, int);
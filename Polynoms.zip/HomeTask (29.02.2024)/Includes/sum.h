#include "Polynom.h"
Polynom sum(Polynom*, int);
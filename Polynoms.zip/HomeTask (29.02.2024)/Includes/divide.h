#include "Polynom.h"
Polynom divide(Polynom*, int);
#include "Polynom.h"
Polynom getDiffer(Polynom*, int);
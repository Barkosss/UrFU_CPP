#include <string>

struct Actions {
    int counter;
    std::string *array;
};
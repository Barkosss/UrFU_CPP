#include "Polynom.h"
int getValue(Polynom*, int, int);
#include <string>
bool checkInteger(std::string);
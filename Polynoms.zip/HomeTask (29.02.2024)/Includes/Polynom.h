struct Polynom {
    int length;
    int *array;
};
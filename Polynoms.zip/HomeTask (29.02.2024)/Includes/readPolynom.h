#include <fstream>
#include "Polynom.h"
void readPolynom(std::ifstream&, std::ofstream&, Polynom*);
#include <fstream>
void writePolynom(std::ofstream&, int*);
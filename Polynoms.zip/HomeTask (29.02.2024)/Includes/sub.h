#include "Polynom.h"
Polynom sub(Polynom*, int);
#include "Polynom.h"
Polynom getFactorDiffer(Polynom*, int);
#include<iostream>
#include<fstream>

#include "readPolynom.h"

using std::cin;
using std::cout;
using std::endl;
using std::ifstream;
using std::ofstream;

int main() {
    ifstream readFile("data.txt");
    ofstream writeFile("result.txt");

    int counterPolynoms;
    readFile >> counterPolynoms;

    for(int indexPolynom = 0; indexPolynom < counterPolynoms; indexPolynom++) {
        Polynom **polynoms = new Polynom*[counterPolynoms];
        readPolynom(readFile, writeFile, *polynoms);
    }

    return 0;
}
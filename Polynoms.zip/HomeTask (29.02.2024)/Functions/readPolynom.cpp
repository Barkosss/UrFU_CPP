#include<iostream>
#include<fstream>
#include<string>

#include "readPolynom.h"
#include "Actions.h"
#include "Polynom.h"
#include "sum.h"
#include "sub.h"
#include "multi.h"
#include "divide.h"
#include "getDiffer.h"
#include "getFactorDiffer.h"
#include "checkInteger.h"
#include "getValue.h"

using std::cout;
using std::endl;
using std::string;
using std::ifstream;
using std::ofstream;

void readPolynom(ifstream&readFile, ofstream&writeFile, Polynom* polynoms) {
    ifstream readFile("date.txt");
    ofstream writeFile("result.txt");

    if (!readFile.is_open()) {
        cout << "Error: Read file isn't open" << endl;
        return;
    }

    if (!writeFile.is_open()) {
        cout << "Error: Write file isn't open" << endl;
        return;
    }

    int counterPolynoms, counterActinos, counterFactor;
    readFile >> counterPolynoms >> counterActinos;

    Actions actions;
    string *arrayString = new string[counterActinos];
    // Чтение действий
    for(int indexAction = 0; indexAction < counterActinos; indexAction++) {
        readFile >> arrayString[indexAction];
    }
    actions.counter = counterActinos;
    actions.array = arrayString;

    for(int indexPolynom = 0; indexPolynom < counterPolynoms; indexPolynom++) {
        Polynom arrayPolynom;
        // Количество коэффициентов
        readFile >> counterFactor;
        arrayPolynom.length = counterFactor;
        // Массив из коэффициентов
        int *array = new int[counterFactor];
        for(int indexFactor = 0; indexFactor < counterFactor; indexFactor++) {
            readFile >> array[counterFactor - indexFactor - 1];
        }
        arrayPolynom.array = array;
        polynoms[indexPolynom] = arrayPolynom;
    }

    string action;
    int intResult;
    Polynom polynomResult;
    for(int indexAction = 0; indexAction < counterActinos; indexAction++) {
        action = actions.array[indexAction];    
        if (action == "sum") { // Сумма многочленов
            polynomResult = sum(polynoms, counterPolynoms);
        }
        else if (action == "sub") { // Разность многочленов
            polynomResult = sub(polynoms, counterPolynoms);
        }
        else if (action == "multi") { // Произведение многочленов
            polynomResult = multi(polynoms, counterPolynoms);
        }
        else if (action == "divide") { // Частное от многочленов
            polynomResult = divide(polynoms, counterPolynoms);
        }
        else if (action == "getDiffer") { // Получить производную
            polynomResult = getDiffer(polynoms, counterPolynoms);
        }
        else if (action == "getFactorDiffer") { // Получить коэффициенты производной
            polynomResult = getFactorDiffer(polynoms, counterPolynoms);
        }
        else if (action == "getValue") { // Получить значение в точке
            string stringValue = actions.array[indexAction++];

            // Проверка, что строка является целым числом
            if (!checkInteger(stringValue)) {
                cout << "Error: The value for finding a function at a point is not an integer" << endl;
                return;
            }

            int intValue = stoi(stringValue);
            intResult = getValue(polynoms, counterPolynoms, intValue);
        }
        else { // Если не было найдено действие
            cout << "Action: \"" << action << "\" isn't found" << endl;
        }
    }

    return;
}
#include<iostream>

#include "multi.h"

Polynom multi(Polynom* polynoms, int counterPolynoms) {
    Polynom result;
    int sumCounterFactors = 0;
    for(int indexPolynom = 0; indexPolynom < counterPolynoms; indexPolynom++) {
        sumCounterFactors += polynoms[indexPolynom].length;
    }

    

    return result;
}
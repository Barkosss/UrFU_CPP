#include<iostream>

#include "sub.h"

Polynom sub(Polynom*polynoms, int counterPolynoms) {
    Polynom result;
    int maxCounterFactor = 0, counterFactor, *arrayFactor;

    // Пробегаемся по многочленам
    for(int indexPolynom = 0; indexPolynom < counterPolynoms; indexPolynom++) {
        counterFactor = polynoms[indexPolynom].length;
        maxCounterFactor = (counterFactor > maxCounterFactor) ? (counterFactor) : (maxCounterFactor);
        // Пробегаемся по коэффициентам многочлена
        for(int indexFactor = 0; indexFactor < counterFactor; indexFactor++) {
            arrayFactor[indexFactor] -= polynoms[indexPolynom].array[indexFactor];
        }
    }

    result.length = maxCounterFactor; // Длина многочлена
    result.array = arrayFactor; // Коэффициенты многочлена

    return result;
}